//package Week3;

import java.util.ArrayList;

public class VisitorPattern {

	public static void main(String[] args){
		SUTD oneSUTD = new SUTD ();
		Auditor auditor = new Auditor();
		
		ArrayList<Employee> employees = oneSUTD.getEmployee();

		//auditing
		for (Employee employee : employees) {
		    employee.accept(auditor);
		}	
	}
}

class SUTD {
    private ArrayList<Employee> employee;

    public SUTD () {
        employee = new ArrayList<Employee>();
        employee.add(new Professor("Sun Jun", 0));
        employee.add(new AdminStuff("Stacey", 5));
        employee.add(new Student("Allan", 3));
    }

    public ArrayList<Employee> getEmployee () {
        return employee;
    }
}

interface Visitor {
    public void visit(Employee employee);
    public void visit(Professor professor);
    public void visit(AdminStuff adminStuff);
    public void visit(Student student);
}

class Auditor implements Visitor {

    @Override
    public void visit(Employee employee) {
    }

    @Override
    public void visit(Professor professor) {
        System.out.println("Professor: " + Professor.getName() + ", " + Professor.getNo_of_publications());
    }

    @Override
    public void visit(AdminStuff adminStuff) {
        System.out.println("Admin Staff: " + AdminStuff.getName() + ", " + AdminStuff.getEfficiency());
    }

    @Override
    public void visit(Student student) {
        System.out.println("Student: " + Student.getName() + ", " + Student.getGPA());
    }
}

interface Visitable {
    public void accept(Visitor visitor);
}

class Employee implements Visitable {
    @Override
    public void accept(Visitor visitor) {
        visitor.visit(this);
    }
}

class Professor extends Employee implements Visitable {
    @Override
    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    private static String name;
    private static int no_of_publications;

    public Professor (String name, int no_of_publications) {
        this.name = name;
        this.no_of_publications = no_of_publications;
    }

    public static String getName() {
        return name;
    }

    public static int getNo_of_publications() {
        return no_of_publications;
    }
}

class AdminStuff extends Employee implements Visitable {
    @Override
    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    private static String name;
    private static float efficiency;

    public AdminStuff (String name, float efficiency) {
        this.name = name;
        this.efficiency = efficiency;
    }

    public static String getName() {
        return name;
    }

    public static float getEfficiency() {
        return efficiency;
    }
}

class Student extends Employee implements Visitable {
    @Override
    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    private static String name;
    private static float GPA;

    public Student (String name, float GPA) {
        this.name = name;
        this.GPA = GPA;
    }

    public static String getName() {
        return name;
    }

    public static float getGPA() {
        return GPA;
    }
}