import java.util.Arrays;
import java.util.Scanner;

/**
 * Created by e6440 on 2/25/2018.
 */

public class VoteCastingDP {
    // Java program for sequential election vote casting application

    public static void main(String[] args){

        Candidate candidate = null;

        Scanner userInput = new Scanner(System.in);

        String candidateOption = "";

        int electorates = 5;
        int candidates = 2;

        CandidateFactory initfactory = new CandidateFactory();
        initfactory.initialise(candidates);

        for (int i = 0; i < electorates; i++) {

            while (true) {
                System.out.print("Electorate " + (i+1) + ", cast your vote (A or B):");
                if (userInput.hasNextLine()){
                    candidateOption = userInput.nextLine();
                }

                CandidateFactory factory = new CandidateFactory();
                candidate = factory.makeVote(candidateOption);

                try {
                    castVote(candidate);
                    break;
                } catch (Exception ex) {
                    System.out.println("Invalid vote cast.");
                }
            }
        }
        candidate.displayResults();
    }

    public static void castVote(Candidate aCandidate){
        aCandidate.displayVotes();
    }
}

class CandidateFactory {

    public void initialise(int candidates) {
        Candidate.name = new String[candidates];
        Candidate.name[0] = "Candidate A";
        Candidate.name[1] = "Candidate B";
        Candidate.votes = new int[candidates];
    }

    public Candidate makeVote(String candidateOption) {
        Candidate candidate = null;

        if (candidateOption.equals("A")){
            return new Candidate_A();
        } else if (candidateOption.equals("B")){
            return new Candidate_B();
        } else {
            return null;
        }
    }
}

abstract class Candidate {

    static String[] name;

    static int[] votes;

    public String getName(int i) {
        return name[i];
    }

    public void setName(String newName, int i) {
        name[i] = newName;
    }

    public int getVotes(int i) {
        return votes[i];
    }

    public void setVotes(int[] newVotes) {
        votes = newVotes;
    }

    public void addVotes(int i) {
        votes[i] += 1;
    }

    public void displayVotes() {
        for (int i = 0; i < votes.length; i++) {
            System.out.println(getName(i) + " has " + getVotes(i) + " votes.");
        }
    }

    public void displayResults() {
        int winner = 0;
        int max = Integer.MIN_VALUE;
        for (int i = 0; i < votes.length; i++) {
            if (getVotes(i) > max) {
                max = getVotes(i);
                winner = i;
            }
        }
        System.out.println(getName(winner) + " wins the election!");
    }

}

class Candidate_A extends Candidate {
    public Candidate_A() {
        setName("Candidate A", 0);
        addVotes(0);
    }
}

class Candidate_B extends Candidate {
    public Candidate_B() {
        setName("Candidate B", 1);
        addVotes(1);
    }
}