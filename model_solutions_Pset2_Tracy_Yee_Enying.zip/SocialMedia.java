//package Week3;

import java.util.ArrayList;

//Uses the Subject interface to update all Observers
// maintains the list of all subscribers to the pricing scheme
// However, not really aware of what type of subscribers they are (e.g. University/Corporate/Individual)

public class SocialMedia implements Subject {
    // a social media that displays a number of posts

    private ArrayList<String> postsContent; // list of posts containing content of posts
    private ArrayList<ArrayList<String>> postsComment; // list of posts containing comments of posts
	private ArrayList<ArrayList<Observer>> observers; // list of posts containing subscribers (index is postID)
    private int newPostID = 0;
    private ArrayList<Integer> likes;
	
	public SocialMedia(){
		postsContent = new ArrayList<String>();
		postsComment = new ArrayList<ArrayList<String>>();
		likes = new ArrayList<Integer>();
		observers = new ArrayList<ArrayList<Observer>>(); // creates an ArrayList to hold all observers
	}
	
	public void register(int postID, Observer newObserver) {
		observers.get(postID).add(newObserver); // adds a new observer to the ArrayList
	}

	public void unregister(int postID, Observer deleteObserver) {
        // any subscriber can leave from the subscription at any time
		int observerIndex = observers.indexOf(deleteObserver); // get the index of the observer to delete
		System.out.println("Observer " + (observerIndex+1) + " deleted"); // print out message (increment index to match)
		observers.get(postID).remove(observerIndex); // remove observer from the ArrayList
	}

	public void notifyObserver(int postID) {
        // subscribers only receive notifications for the posts they are subscribed to
		// cycle through all subscribers of the post and notifies them immediately
        // when the post is edited or some other subscriber comments to the post
        for(Observer observer : observers.get(postID)){
            observer.update(postsContent.get(postID));
		}
	}

    public int getNewPostID() {
        return newPostID;
    }

    public void setNewPostID(){
	    newPostID += 1;
    }

    public void updatePostsContent(int postID, String newContent){
        postsContent.set(postID,newContent);
    }

    public void updatePostsComment(int postID, String newComment){
        postsComment.get(postID).add(newComment);
    }

    public ArrayList<String> getPostsComment(int postID) {
        return postsComment.get(postID);
    }

    public void getObservers(int postID) {
        for (Observer observer : observers.get(postID)) {
            System.out.println(observer);
        }
    }

    public String getPostsContent(int postID) {
        return postsContent.get(postID);
    }

    public void addLikes(int postID) {
        likes.set(postID,(likes.get(postID)+1));
    }

    public void minusLikes(int postID) {
        likes.set(postID,(likes.get(postID)-1));
    }

    public Integer getLikes(int postID) {
        return likes.get(postID);
    }
}
