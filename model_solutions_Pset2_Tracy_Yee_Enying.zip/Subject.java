//package Week3;

public interface Subject {
    public void register(int postID, Observer o);
    public void unregister(int postID, Observer o);
	public void notifyObserver(int postID);
}
