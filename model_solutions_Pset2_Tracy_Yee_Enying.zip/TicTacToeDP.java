import java.util.Arrays;
import java.util.Scanner;

/**
 * Created by e6440 on 2/25/2018.
 */

public class TicTacToeDP {
    // two players ('X' and 'O') take turns to make a move
    // the game is over after a winner is decided

    public static void main(String[] args) {

        Game game = null;

        Scanner userInput = new Scanner(System.in);

        String gameOption = "";

        System.out.println("Which game do you want to play? (T: tic-tac-toe)");

        if (userInput.hasNextLine()) {
            gameOption = userInput.nextLine();
        }

        GameFactory factory = new GameFactory();
        game = factory.makeGame(gameOption);

        try {
            playGame(game);
        } catch (Exception ex) {
            System.out.println("Game does not exist.");
        }
    }

    public static void playGame(Game game) {
        game.play();
    }

}

class GameFactory {

    public Game makeGame(String gameOption){

        if (gameOption.equals("T")){
            System.out.println("Game Chosen: Tic-Tac-Toe");
            return new TicTacToeGame();
        }

        else
            return null;
    }
}

abstract class Game {

    private String results;

    public String getResults() {
        return results;
    }

    public void setResults(String newResults) {
        results = newResults;
    }

    public void displayResults(){
        System.out.println("Results: " + getResults());
    }

    public void play() {
    }
}

class TicTacToeGame extends Game{
    // two players ('-1' and '1') take turns to make a move
    // the game is over after a winner is decided

    static int gridSize = 3; // default grid size of Tic-Tac-Toe game is 3x3
    static boolean playing;
    static int currentPlayer;

    public void play() {

        // initialise game with empty grid
        int[][] grid = new int[gridSize][gridSize]; //elements in grid initialised to 0
        playing = true;
        currentPlayer = 1;
        Scanner userInput = new Scanner(System.in);
        System.out.println("Player " + currentPlayer + "'s turn. Please enter your move (1-9).");
        System.out.println(Arrays.deepToString(grid).replace("], ", "]\n"));

        while (playing) {
            int move = 0;
            try {
                move = userInput.nextInt();
                System.out.println("Player " + currentPlayer + " has chosen slot " + move);
            } catch (Exception ex) {
                System.out.println("Slot chosen is invalid. Please try again.");
                userInput.next();
            }
            if (move >= 1 && move <= 9) {
                //System.out.println("valid slot selected");
                //System.out.println(((move-1)/3) + ", " + ((move-((move-1)/3)*3)-1));
                if (!(grid[(move-1)/3][(move-((move-1)/3)*3)-1] == 0)) {
                    System.out.println("Slot is already taken. Player " + currentPlayer + ", please try again.");
                    System.out.println(Arrays.deepToString(grid).replace("], ", "]\n"));
                }
                else {
                    //grid[(move-1)/3][(move-((move-1)/3)*3)-1] = currentPlayer;
                    //checkState(grid);
                    if (currentPlayer == 1) {
                        grid[(move-1)/3][(move-((move-1)/3)*3)-1] = -1;
                        if (winGame(grid)) {
                            System.out.println(Arrays.deepToString(grid).replace("], ", "]\n"));
                            playing = false;
                            System.out.println("Game ends! Player 1 wins!");
                            break;
                        }
                        currentPlayer = 2;
                    }
                    else {
                        grid[(move-1)/3][(move-((move-1)/3)*3)-1] = 1;
                        if (winGame(grid)) {
                            System.out.println(Arrays.deepToString(grid).replace("], ", "]\n"));
                            playing = false;
                            System.out.println("Game ends! Player 2 wins!");
                            break;
                        }
                        currentPlayer = 1;
                    }
                    System.out.println("Player " + currentPlayer + "'s turn. Please enter your move (1-9).");
                    System.out.println(Arrays.deepToString(grid).replace("], ", "]\n"));
                }
            }
            else if (move < 1 || move > 9){
                System.out.println("Slot chosen is out of grid size. Please try again.");
            }
        }
    }

    public static boolean winGame(int[][] grid) {
        if (grid[0][0] + grid[0][1] + grid[0][2] >= 3 || grid[0][0] + grid[0][1] + grid[0][2] <= -3
                || grid[1][0] + grid[1][1] + grid[1][2] >= 3 || grid[1][0] + grid[1][1] + grid[1][2] <= -3
                || grid[2][0] + grid[2][1] + grid[2][2] >= 3 || grid[2][0] + grid[2][1] + grid[2][2] <= -3
                || grid[0][0] + grid[1][0] + grid[2][0] >= 3 || grid[0][0] + grid[1][0] + grid[2][0] <= -3
                || grid[0][1] + grid[1][1] + grid[2][1] >= 3 || grid[0][1] + grid[1][1] + grid[2][1] <= -3
                || grid[0][2] + grid[1][2] + grid[2][2] >= 3 || grid[0][2] + grid[1][2] + grid[2][2] <= -3
                || grid[0][0] + grid[1][1] + grid[2][2] >= 3 || grid[0][0] + grid[1][1] + grid[2][2] <= -3
                || grid[0][2] + grid[1][1] + grid[2][0] >= 3 || grid[0][2] + grid[1][1] + grid[2][0] <= -3) {

            return true;
        }

        return false;
    }

}

