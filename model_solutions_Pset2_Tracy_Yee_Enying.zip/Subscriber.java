//package Week3;

//Represents each Observer that is monitoring changes in the subject

import java.util.ArrayList;

public class Subscriber implements Observer {

	private ArrayList<Integer> myPosts; // list containing ids of posts created by this subscriber
	private static int observerIDTracker = 0; // static used as a counter
	private int observerID; // used to track the observers

	private SocialMedia SocialMedia; // will hold reference to the StockGrabber object
	
	public Subscriber(SocialMedia socialMedia){
	    this.myPosts = new ArrayList<Integer>();
		this.SocialMedia = socialMedia; // store the reference to the pricingScheme object so can make calls to its methods
		this.observerID = ++observerIDTracker; // assign an observer ID and increment the static counter
		System.out.println("New Observer " + this.observerID); // message notifies user of new observer
		//socialMedia.register(this); // add the observer to the Subjects ArrayList
	}

	public void update(String postsContent) {
	    // called to update all observers
	}

    public int getObserverID() {
        return observerID;
    }

    // make a new post
	public void createPost(String editContent) {
        this.myPosts.add(SocialMedia.getNewPostID());
        SocialMedia.updatePostsContent(SocialMedia.getNewPostID(),editContent);
	    SocialMedia.setNewPostID();
    }

    // subscribe to a post
    public void subscribePost(int postID) {
        SocialMedia.register(postID,this);
    }

    // edit a post (only allowed for the subscriber who posted initially)
    public void editPost(int postID, String newContent) {
	    for (int i = 0; i < myPosts.size(); i++) {
            if (myPosts.get(i) == postID && postID < SocialMedia.getNewPostID()) {
                System.out.println("edit post");
                SocialMedia.updatePostsContent(postID,newContent);
                SocialMedia.notifyObserver(postID);
            }
        }
    }

    public String viewPost(int postID) {
	    return SocialMedia.getPostsContent(postID);
    }

    // comment on a post
    public void commentPost(int postID, String newComment) {
        SocialMedia.updatePostsComment(postID,newComment);
    }

    public ArrayList<String> viewComments(int postID) {
        return SocialMedia.getPostsComment(postID);
    }

    public Integer viewLikes(int postID) {
	    return SocialMedia.getLikes(postID);
    }

    // leave a post
    public void leavePost(int postID) {
	    SocialMedia.unregister(postID,this);
    }
}
