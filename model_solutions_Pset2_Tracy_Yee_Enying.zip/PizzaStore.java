//package Week3;

public class PizzaStore {
	// refactored using Factory Design Pattern

	public Pizza orderPizza (String type) {
		Pizza pizza = null;
		PizzaFactory pizzaFactory = new PizzaFactory();
		pizza = pizzaFactory.makePizza(type);

		pizza.prepare();
		pizza.bake();
		pizza.cut();
		pizza.box();
		
		return pizza;
	}
}

class PizzaFactory {

    public Pizza makePizza(String type) {
        Pizza pizza = null;

        if (type.equals("cheese")) {
            pizza = new CheesePizza();
        }
        if (type.equals("greek")) {
            pizza = new GreekPizza();
        }
        if (type.equals("pepperoni")) {
            pizza = new PepperoniPizza();
        }
        return pizza;
    }
}

class Pizza {

	public void prepare() {
	}

	public void box() {
	}

	public void cut() {
	}

	public void bake() {
	}
}

class CheesePizza extends Pizza {}
class GreekPizza extends Pizza {}
class PepperoniPizza extends Pizza {}

