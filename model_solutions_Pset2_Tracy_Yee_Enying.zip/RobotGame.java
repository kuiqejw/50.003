//package Week3;

interface IBehaviour {
    public int moveCommand();
}

class AggressiveBehaviour implements IBehaviour {
    public int moveCommand() {
        //System.out.println("Aggressive Robot");
        return 1;
    }
}

class DefensiveBehaviour implements IBehaviour {
    public int moveCommand() {
        //System.out.println("Defensive Robot");
        return -1;
    }
}

class NormalBehaviour implements IBehaviour {
    public int moveCommand() {
        //System.out.println("Normal Robot");
        return 0;
    }
}

class Robot {
	String name;
	IBehaviour behaviour;

	public Robot (String name)
	{
		this.name = name;
	}

	public void behave ()
	{
		//the robots behave differently
        System.out.println(getName() + ": " + behaviour.moveCommand());
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public void setBehavior(IBehaviour behavior) {
		//todo
        this.behaviour = behavior;
	}
}

public class RobotGame {

	public static void main(String[] args) {

		Robot r1 = new Robot("Big Robot");
		Robot r2 = new Robot("George v.2.1");
		Robot r3 = new Robot("R2");

        System.out.println("Robot behaviour (displacement towards other robots) when they meet:");

        r1.setBehavior(new AggressiveBehaviour());
		r2.setBehavior(new DefensiveBehaviour());
		r3.setBehavior(new NormalBehaviour());
		
		r1.behave();
		r2.behave();
		r3.behave();

        System.out.println("New robot behaviour (displacement towards other robots) when they meet:");
		//change the behaviors of each robot.
		r1.setBehavior(new NormalBehaviour());
		r2.setBehavior(new AggressiveBehaviour());
		r3.setBehavior(new DefensiveBehaviour());
		
		r1.behave();
		r2.behave();
		r3.behave();
	}
}
