package com.example.Term6.Week5;

import org.junit.Test;

/**
 * Created by reube on 27/2/2018.
 */

public class DiskFaultTest {
    @Test public void checkDiskBug(){
        Disk d = new Disk(1001,-2);
        d.manipulate();
    }
}
