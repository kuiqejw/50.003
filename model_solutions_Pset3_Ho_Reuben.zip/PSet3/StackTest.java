//package Week4;
package com.example.Term6.Week5;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class StackTest {
	private Stack<Integer> stack;
	// setUp method using @Before syntax
	// @Before methods are run before each test
	@Before 
	public void runBeforeEachTest()
	{
		System.out.println("setting up");
		
	    stack = new Stack<Integer>();
	}

	// tear-down method using @After
	// @After methods are run after each test
	@After 
	public void runAfterEachTest()
	{
	    stack = null;
		System.out.println("setting down");
	}

	@Test public void testToString()
	{
		System.out.println("testing");
	   stack.push(new Integer(1));
	   stack.push(new Integer(2));
	   assertEquals ("{2, 1}", stack.toString());
	}
	
	@Test public void testRepOk()
	{
	   boolean result = stack.repOK();
	   assertEquals (true, result);
	   stack.push (new Integer (1));
	   result = stack.repOK();
	   assertEquals (true, result);
	   stack.pop();
	   result = stack.repOK();
	   assertEquals (true, result);
	   stack.push (new Integer (1));
	   stack.pop();
	   result = stack.repOK();
	   assertEquals (true, result);
	}
	@Test public void testPush()
		{
			boolean result ;
			stack.push (new Integer (1));
			result = stack.repOK();
			// result will be false as this.empty() != this.elements().hasMoreElements() will always evaluate to true, so repOk will always return false, although the code is correct
			assertEquals (true, result);
	}
	@Test public void testPushNothing()
	{
		boolean result ;
		stack.push (null);
		result = stack.repOK();
		assertEquals (false, result);
	}
	@Test public void testPopNotEmpty()
		{
			boolean result;
			stack.push (new Integer (1));
			stack.pop();
			result = stack.repOK();
			// result will be false as this.empty() != this.elements().hasMoreElements() will always evaluate to true, so repOk will always return false, although the code is correct
			assertEquals (true, result);
	}

	@Test public void testPopNothing(){
		boolean result;
		stack.pop();
		result = stack.repOK();
		assertEquals (false, result);
	}
}
