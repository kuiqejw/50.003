package com.example.Term6.Week5;

/**
 * Created by reube on 19/2/2018.
 */
import static org.junit.Assert.*;

import org.junit.Test;

public class FindMaxTest {
    @Test
    public void testMaxFail(){
        assertTrue(FindMax.max(new int[]{2,6,17,8,25}) ==25);
    }
    @Test
    public void testMaxError(){
        try {
            int max = FindMax.max(new int[]{});
            fail("Expected exception did not occur");
        }catch (Exception e){
            System.out.println(e.toString());
        }
    }
    @Test
    public void testMaxPass(){
        assertTrue(FindMax.max(new int[]{2,6,17,8,2}) ==17);
    }
}
