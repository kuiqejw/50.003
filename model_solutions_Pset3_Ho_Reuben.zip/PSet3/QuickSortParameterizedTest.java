package com.example.Term6.Week5;

import org.junit.*;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

/**
 * Created by reube on 19/2/2018.
 */
@RunWith(Parameterized.class)
public class QuickSortParameterizedTest {
    int[] sorted, unsorted;

    public QuickSortParameterizedTest(int[] sorted, int[] unsorted) {
        this.sorted = sorted;
        this.unsorted = unsorted;
    }

    @Parameterized.Parameters
    public static Collection<Object[]> parameters(){
        return Arrays.asList(new Object[][]{{new int[]{1,2,5,7}, new int[]{2,7,5,1}},
                                            {new int[]{1,3,5,7,9}, new int[]{9,5,7,1,3}}
    });
    }

    @Test
    public void sortTest(){
        QuickSort sort = new QuickSort();
        sort.sort(unsorted);
        assertArrayEquals(sorted,unsorted);

    }
}
