package com.example.Term6.Week5;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created by reube on 27/2/2018.
 */

public class RussianTest {
    //Test suite for black-box testing
    @Test
    public void testNeg1(){
        assertEquals (-10, Russian.multiply(-2,5));
    }
    @Test
    public void testNeg2(){
        assertEquals (-10, Russian.multiply(2,-5));
    }
    @Test
    public void testZero1(){
        assertEquals (0, Russian.multiply(2,0));
    }
    @Test
    public void testZero2(){
        assertEquals (0, Russian.multiply(-2,0));
    }
    @Test
    public void testZero3(){
        assertEquals (0, Russian.multiply(0,5));
    }
    @Test
    public void testZero4(){
        assertEquals (0, Russian.multiply(0,5));
    }
    @Test
    public void testZero5(){
        assertEquals (0, Russian.multiply(0,0));
    }
    @Test
    public void testPos1(){
        assertEquals (10, Russian.multiply(-2,-5));
    }
    @Test
    public void testPos2(){
        assertEquals (10, Russian.multiply(2,5));
    }
    @Test
    public void testOverflow(){
        assertEquals (500*2147483647, Russian.multiply(2147483647,500));
    }
    @Test
    public void testUnderflow(){
        assertEquals (-500*2147483647, Russian.multiply(-2147483647,500));
    }


    //Test suite for white-box testing, for 100% branch coverage. Include black-box testings for boundary value analysis as well.
    @Test
    public void testBranch1NisEven(){
        assertEquals (18, Russian.multiply(3,6));
    }
    @Test
    public void testBranch2NisOdd(){
        assertEquals (18, Russian.multiply(6,3));
    }
    @Test
    public void testBranch3NisNegative(){
        assertEquals (-18, Russian.multiply(6,-3));
    }
    @Test
    public void testBranch2(){
        assertEquals (18, Russian.multiply(6,3));
    }
    //Test suite for fault-based testing
    @Test
    public void testFaultNull1(){
        assertEquals (null, Russian.multiply(new Integer(null),6));
    }
    @Test
    public void testFaultNull2(){
        assertEquals (null, Russian.multiply(6,new Integer(null)));
    }
    @Test
    public void testFaultText1(){
        assertEquals (null, Russian.multiply(new Integer("not int"),6));
    }
    @Test
    public void testFaultText2(){
        assertEquals (null, Russian.multiply(6,new Integer("not int")));
    }

}
