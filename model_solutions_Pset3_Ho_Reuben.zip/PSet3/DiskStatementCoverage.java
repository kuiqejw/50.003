package com.example.Term6.Week5;

import org.junit.*;

/**
 * Created by reube on 26/2/2018.
 */

public class DiskStatementCoverage {
    @Test
    public void TestXGreater5Less1000(){
        Disk d = new Disk(6,0);
        d.manipulate();
    }
    @Test
    public void TestYLess12XLess5(){
        Disk d = new Disk(4,5);
        d.manipulate();
    }
    @Test
    public void TestYLess1XGreater1000(){
        Disk d = new Disk(1010,0);
        d.manipulate();
    }
    //3 tests needed, yes it is the minimum.
    //     /* For all the tests, it will cover the statements: threshold = 1000, (threshold -(x+y)>0). TestXGreater5Less1000() will cover the statements from the first if,else-if X>5, to X<=1000 of the second if,else-if. TestYLess12XLess5() then covers the statements when Y<=12 in the first if. else-if, and X<=1000 in the second if,else-if. TestYLess1XGreater1000() would cover the statements from the first if,else-if of X>5, to the Y<1 of the second if,else-if. Although there are overlaps, this would essentially cover all statements.

}
