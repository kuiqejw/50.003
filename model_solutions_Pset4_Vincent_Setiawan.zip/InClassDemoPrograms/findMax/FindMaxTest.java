import org.junit.Test;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.Expectations;

public class FindMaxTest {
	@Test
	public void testFindMax() {
		Mockery context = new JUnit4Mockery();

		final Sorter sorter = context.mock(Sorter.class);

		context.checking(new Expectations() {{
			oneOf (sorter).sort(new int[]{5,3,2,1,24,6,7,30});
			will(returnValue(new int[]{1,2,3,5,6,7,24,30}));
		}});


		FindMaxUsingSorting fmus = new FindMaxUsingSorting();
		FindMaxUsingSorting.findmax(new int[]{5,3,2,1,24,6,7,30}, sorter);

		context.assertIsSatisfied();
	}
}
