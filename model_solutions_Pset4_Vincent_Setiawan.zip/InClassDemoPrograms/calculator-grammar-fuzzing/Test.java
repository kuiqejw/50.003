import java.util.HashMap;

class Test{

	public static void main(String[] args) {
		HashMap<String,String> hm = new HashMap<>();
		System.out.println(hm.get("a") == null);
	}
}
