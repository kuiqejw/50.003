import java.util.HashMap;
import java.util.Random;
/*
Fuzzer based on grammar
params:
	HashMap<String, String[][]> grammar: The grammar used for the fuzzer
	String root: The root of the grammar
	int maxDepth: Maximum number of literals in the output
Each grammar is saved in a HashMap<String,String[][]>
String:
	The basic unit of grammar
String[][]:
	first level array:
		-All possible rules for that unit.
		-First member of the array is always an array with one String representing the type of that unit,
		whether it is a branch(members may have another unit as part of the rule) or a leaf(All members are literal)
		-Second member of the array is always a rule where it will not go back up the tree. (Prevent overflow)
	second level array:
		-Array of the format of that rule.

Example of the Grammar using a basic Calculator grammar is provided below
**/

class CalculatorFuzzer {
	public static void main(String[] args) {

		HashMap<String, String[][]> grammar = new HashMap<>();

		String[][] grammar1 = new String[][]{ new String[] {"branch"},
																					new String[] {"Expr"}
																				};
		grammar.put("S", grammar1);

		String[][] grammar2 = new String[][]{	new String[] {"branch"},
																					new String[]{"Term"},
																					new String[]{"Expr", "–", "Term"},
																					new String[]{"Expr", "+", "Term"}
																				};
		grammar.put("Expr", grammar2);

		String[][] grammar3 = new String[][]{	new String[]{"branch"},
																					new String[]{"Factor"},
																					new String[]{"Term", "/", "Factor"},
																					new String[] {"Term", "*", "Factor"}
																				};
		grammar.put("Term", grammar3);

		String[][] grammar4 = new String[][]{	new String[] {"branch"},
																					new String[]{"Integer"},
																					new String[]{"(", "Expr", ")"},
																					new String[]{"-", "Integer"},
																					new String[]{"Integer",".","Integer"}
																				};
		grammar.put("Factor", grammar4);

		String[][] grammar5 = new String[][]{	new String[]{"branch"},
																					new String[]{"Digit"},
																					new String[]{"Integer", "Digit"}
																				};
		grammar.put("Integer", grammar5);

		String[][] grammar6 = new String[][]{	new String[]{"leaf"},
																					new String[]{"0"},
																					new String[]{"1"},
																					new String[]{"2"},
																					new String[]{"3"},
																					new String[]{"4"},
																					new String[]{"5"},
																					new String[]{"6"},
																					new String[]{"7"},
																					new String[]{"8"},
																					new String[]{"9"}
																				};
		grammar.put("Digit", grammar6);

		CalculatorFuzzer fuzzer = new CalculatorFuzzer(grammar, "S", 500);
		System.out.println(fuzzer.getFuzzed());
	}

	HashMap<String, String[][]> grammar;
	String[][] children;
	String[] chosenArray;
	String globalFuzzed;
	Random randomizer;
	int depth, maxDepth;

	CalculatorFuzzer(HashMap<String, String[][]> grammar, String root, int maxDepth) {
		this.grammar = grammar;
		this.randomizer = new Random();
		this.maxDepth = maxDepth;
		globalFuzzed = fuzz(root);
	}

	String getFuzzed(){
		return globalFuzzed;
	}

	String fuzz(String fizz){
		depth++;
		String fuzzed = "";
		children = grammar.get(fizz);
		if (children == null) {
			System.out.println(fizz);
			return fizz;
		}
		int next;
		if (depth > maxDepth && children[0][0].equals("branch")) {
			next = 0;
		} else {
			next = randomizer.nextInt(children.length - 1);
		}
		String[] chosenArray = children[next + 1];
		for (String baby: chosenArray) {
			fuzzed += fuzz(baby);
		}
		return fuzzed;
	}

}
