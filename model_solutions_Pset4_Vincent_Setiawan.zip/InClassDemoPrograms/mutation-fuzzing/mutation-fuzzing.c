#include <stdlib.h>
#include <assert.h>
#include <time.h>
#include <stdio.h>
#include <string.h>

// Flipping a random bit of a random character in the input string
void flip(char* input) {
	int flip_position, flip_bit;


	// choose a random position in the input string
	flip_position = rand() % (strlen(input) - 1);

	// choose a random bit in the respective character, why it is 7 and not 8?
	flip_bit = rand() % 7;

	printf("Flipping bit %d in position %d.....\n", flip_bit, flip_position);

	// flip the bit in-place
	input[flip_position] = input[flip_position] ^ (1 << flip_bit);

	printf("Mutated input = %s\n", input);

}

void swap(char* input) {
	int swap_position, temp;
	if (strlen(input) <= 1)
	{
		printf("Input length is less than 1 character long, no swapping is done\n");
		return;
	}

	// choose a random position in the input string
	swap_position = rand() % (strlen(input) - 1);

	printf("Swapping adjacent input in position %d.....\n", swap_position);

	// swap the bit in-place
	temp = input[swap_position];
	input[swap_position] = input[swap_position + 1];
	input[swap_position + 1] = temp;

	printf("Mutated input = %s\n", input);

}


// Trimming an input string at a randomly chosen position
void trim(char* input) {
	int trim_position = 0;
	char* mutated_input;

	trim_position = rand() % (strlen(input) - 1);
	printf("Trimming at position %d.....\n", trim_position);

	mutated_input = (char *) malloc ((trim_position + 1) * sizeof(char));
	strncpy(mutated_input, input, trim_position);
	mutated_input[trim_position] = '\0';

	printf("Mutated input = %s\n", mutated_input);
}

int main(int argc, char* argv[]) {
	srand(time(NULL ));
	FILE *fp, *fpout;
	char buff[255];
	char fileout[255];
	strcpy(fileout, "modified-");
	strcat(fileout, argv[1]);
	printf("%s\n",fileout);

	fp = fopen(argv[1], "r");
	fpout = fopen(fileout, "w");

	while(!feof(fp)) {
		fgets(buff, 255, fp);

		strtok(buff, "\n");
		strtok(buff, "\r");

		int random;
		random = rand() % 3;

		if (random == 0) {
			flip(buff);
		} else if (random == 1) {
			trim(buff);
		} else if (random == 2) {
			swap(buff);
		}
		strcat(buff, "\n");
		fputs(buff, fpout);
	}







	// char existing_input[128]="ISTDisApillarInSUTDbutItsNameiSGoingToChange";
	// char* input;
	// int index;

	// printf("Original input = %s\n", existing_input);
	//trim(existing_input);
}

























