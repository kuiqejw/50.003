#include <stdlib.h>
#include <assert.h>
#include <time.h>
#include <stdio.h>
#include <string.h>

// swapping adjacent character of a random position in the input string
void swap(char* input) {
	int swap_position, temp;
	if (strlen(input) <= 1)
	{
		printf("Input length is less than 1 character long, no swapping is done\n");
		return;
	}
	srand(time(NULL));
	// choose a random position in the input string
	swap_position = rand() % (strlen(input) - 1);

	printf("Swapping adjacent input in position %d.....\n", swap_position);

	// swap the bit in-place
	temp = input[swap_position];
	input[swap_position] = input[swap_position + 1];
	input[swap_position + 1] = temp;

	printf("Mutated input = %s\n", input);

}

int main() {
	char existing_input[128]="ISTDisApillarInSUTDbutItsNameiSGoingToChange";
	char* input;
	int index;

	printf("Original input = %s\n", existing_input);
	swap(existing_input);
}
