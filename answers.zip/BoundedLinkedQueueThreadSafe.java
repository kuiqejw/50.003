package Logistics;

public class BoundedLinkedQueueThreadSafe {
	private Node head = null;
	private Node tail = null;
	private int bound, size;
	
	public BoundedLinkedQueueThreadSafe (int bound) {
		this.bound = bound;
	}

	public synchronized void enqueue (String value) throws InterruptedException {
		while (size >= bound) {
			wait();
		}

		Node temp = new Node();
		temp.value = value;
		temp.next = null;
		
		if (head == null) {
			head = temp;
			tail = temp; 
		}
		
		else {
			tail.next = temp;
			tail = temp;
		}
		size++;
	}
	
	public synchronized String dequeue () throws InterruptedException {
		String value = null;
		while (head == null) {
			wait();
		}

		value = head.value;
		head = head.next;
		if (head == null) {
			tail = null;
		}
			
		size--;		
		return value; 
	}
	
	public String toString () {
		String toReturn = "";
		Node temp = head;
		
		while (temp != null) {
			toReturn += " " + temp.value;
			temp = temp.next; 
		}
		return toReturn;		
	}
}
