package Logistics;

import java.util.concurrent.ConcurrentLinkedQueue;

public class BoundedLinkedQueueComposition {
	private final ConcurrentLinkedQueue<String> q; 
	private final int bound;
	private int size;
	
	public BoundedLinkedQueueComposition (int bound) {
		this.q = new ConcurrentLinkedQueue<String> ();
		this.bound = bound;
		size = 0;
	}

	public synchronized void enqueue (String value) throws InterruptedException {
		while (size >= bound) {
			wait();
		}

		q.offer(value);
		size++;
	}
	
	public synchronized String dequeue () throws InterruptedException {
		while (q.isEmpty()) {
			wait();
		}

		size--;		
		return q.poll(); 
	}
}
