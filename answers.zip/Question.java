package Logistics;
import java.util.concurrent.Phaser;

public class Question {
    public static void main(String[] args) throws Exception {
        Phaser phaser = new Phaser(); 		
        MyExaminer exam = new MyExaminer(phaser);
        MyStudent stu = new MyStudent(phaser);
        exam.start();
        stu.start();
    }
}

class MyExaminer extends Thread {	
    private Phaser phaser;
    public MyExaminer (Phaser phaser) {
        this.phaser = phaser;
        this.phaser.register();
    }

    public void run() {
        System.out.println("examiner waiting for students to get ready;");
        phaser.arriveAndAwaitAdvance();
        phaser.arriveAndAwaitAdvance();
        System.out.println("exam has ended");
    }
}

class MyStudent extends Thread {
    private Phaser phaser;
    public MyStudent (Phaser phaser) {
        this.phaser = phaser;
        this.phaser.register();
    }

    public void run() {
        System.out.println("student ready;");
        phaser.arriveAndAwaitAdvance();
        System.out.println("student handing in exam;");
        phaser.arrive();
        System.out.println("student leaves");
    }
}