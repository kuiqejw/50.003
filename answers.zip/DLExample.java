package Logistics;

import java.util.HashSet;
import java.util.Set;

public class DLExample {	
	public static void main (String[] args) {
		final Dispatcher disp = new Dispatcher ();
		final Taxi one = new Taxi(disp);
		disp.addTaxi(one);
		
		Runnable task1 = new Runnable () {
			public void run() {
					disp.getImage();
			}
		};
		
		new Thread(task1).start();
		
		Runnable task2 = new Runnable () {
			public void run() {
					one.setLocation(new Point());;
			}
		};
		
		new Thread(task2).start();
	}
}

class Taxi {
    private Point location, destination;
    private final Dispatcher dispatcher;

    public Taxi(Dispatcher dispatcher) {
        this.dispatcher = dispatcher;
    }

	public synchronized Point getLocation() {
        return location;
    }
    //the fix is here
    public synchronized void setLocation(Point location) {
    	synchronized (dispatcher) {
    		synchronized (this) {
    	        this.location = location;
    	        if (location.equals(destination))
    	            dispatcher.notifyAvailable(this);    			
    		}
    	}
    }

    public synchronized Point getDestination() {
        return destination;
    }
}

class Dispatcher {
    private final Set<Taxi> taxis;
    private final Set<Taxi> availableTaxis;

    public Dispatcher() {
        taxis = new HashSet<Taxi>();
        availableTaxis = new HashSet<Taxi>();
    }
    
    public synchronized void addTaxi(Taxi taxi) {
    	taxis.add(taxi);
    	availableTaxis.add(taxi);
    }

    public synchronized void notifyAvailable(Taxi taxi) {
        availableTaxis.add(taxi);
    }

    public synchronized Image getImage() {
        Image image = new Image();
        for (Taxi t : taxis)
            image.drawMarker(t.getLocation());
        return image;
    }
}

class Image {
    public void drawMarker(Point p) {
    }
}

class Point {
	
}

